<?php

session_start();
echo "Welcome Mr. ".$_SESSION['adminID'];

?>
